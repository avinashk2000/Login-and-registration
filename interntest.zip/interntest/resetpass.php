<?php
    session_start();
    $conn=mysqli_connect("localhost","root","","interntest");
?>  
<html>
    <head>
        <title>Reset Password</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-eMNCOe7tC1doHpGoWe/6oMVemdAVTMs2xqW4mwXrXsW0L84Iytr2wi5v2QjrP/xp" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.min.js" integrity="sha384-cn7l7gDp0eyniUwwAZgrzD06kc/tftFf19TOAs2zVinnD/C7E91j9yyk5//jjpt/" crossorigin="anonymous"></script>
        <style>
            .container-fluid
            {
                background-color: whitesmoke;
                height: 100%;
                
            }
        </style>
    </head>
    <body>
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-4"></div>
                <div class="col-sm-4 bg-light" style="margin-top: 10%; border-radius: 10px;">
                <h4 class="text-center mt-3">Create Password</h4>
                <?php
                    if(isset($_GET['email']))
                    {
                        $email=$_GET['email'];
                        if(isset($_POST['sub']))
                        {
                            $newpass=$_POST['np'];
                            $cnewpass=$_POST['cnp'];
                            if($newpass==$cnewpass)
                            {
                                $up="UPDATE register SET password='$newpass' where email='$email'";
                                $query=mysqli_query($conn,$up) or die(mysqli_error($conn));
                                if($query)
                                {
                                    ?>
                                        <script> alert('New Password Created'); </script>
                                    <?php 
                                    header("location:signin.php");
                                }
                            }
                            else
                            {
                                ?>
                                    <div class="alert alert-danger" role="alert">New Password and Confirm Password was not matched..</div>
                                <?php
                            }
                        }
                    }   
                ?>
                    <form action="" method="post">
                        <label class="mb-2">Create New Password</label>
                        <input type="password" class="mb-3 form-control" name="np" placeholder="create New Password..."/>
                        <label class="mb-2">Confirm Password</label>
                        <input text="password" class="mb-3 form-control" name="cnp" placeholder="Confirm Password..."/>
                        <input type="submit" value="Create Password" class="btn btn-primary btn-block" name="sub"/>
                    </form>
                </div>
                <div class="col-sm-4"></div>
            </div>
        </div>
    </body>
</html>