<html>
    <head>
        <title>Sign In</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-eMNCOe7tC1doHpGoWe/6oMVemdAVTMs2xqW4mwXrXsW0L84Iytr2wi5v2QjrP/xp" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.min.js" integrity="sha384-cn7l7gDp0eyniUwwAZgrzD06kc/tftFf19TOAs2zVinnD/C7E91j9yyk5//jjpt/" crossorigin="anonymous"></script>
        <style>
            .container-fluid
            {
                background-color: whitesmoke;
                height: 100%;
                
            }
        </style>
    </head>
    <body>
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-4"></div>
                <?php
                    session_start();
                    $conn=mysqli_connect("localhost","root","","interntest");
                    if(!$conn)
                    {
                        echo"database connection error";
                    }
                    if(isset($_POST['sub']))
                    {
                        $user_id=$_POST['uid'];
                        $password=$_POST['password'];

                        $sel="SELECT * from register";
                        $query=mysqli_query($conn,$sel) or die(mysqli_error($conn));
                        $data=mysqli_fetch_assoc($query);
                        
                        $_SESSION['email']=$data['email'];
                        $_SESSION['password']=$data['password'];

                        if($user_id==$_SESSION['email'] && $password==$_SESSION['password'])
                        {
                            header("location:index.php");
                        }
                        else
                        {
                            ?>
                                <script>
                                    alert("User Id are password was not matched*");
                                </script>
                            <?php
                        }
                    }
                ?>
                <div class="col-sm-4 bg-light" style="margin-top: 10%; border-radius: 10px;">
                    <h4 class="text-center mt-3 mb-2">Sign in to start your session</h4>
                    <form action="" id="form" method="post" enctype="multipart/form-data">
                        <label class="mb-2">User Id</label>
                        <input type="text" name="uid" id="userid" placeholder="Enter Your user Id..." class="form-control mb-3"/>
                        <label class="mb-2">Password</label>
                        <input type="password" name="password" placeholder="Password..." class="form-control mb-4"/>
                        <a href="forgetpass.php" class="mb-3" style="text-decoration: none;">Forget Password?</a>
                        <a href="Signup.php" class="mb-3" style="text-decoration: none; float: right;">Not Registered?</a><br/>
                        <input type="submit" value="Sign In" class="btn btn-primary mt-3 mb-3" name="sub"/>
                    </form>
                </div>
                <div class="col-sm-4"></div>
            </div>
        </div>
    </body>
</html>