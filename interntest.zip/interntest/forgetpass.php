<?php
    session_start();
    include('constent.php');
?>
<html>
    <head>
        <title>Forget Password</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-eMNCOe7tC1doHpGoWe/6oMVemdAVTMs2xqW4mwXrXsW0L84Iytr2wi5v2QjrP/xp" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.min.js" integrity="sha384-cn7l7gDp0eyniUwwAZgrzD06kc/tftFf19TOAs2zVinnD/C7E91j9yyk5//jjpt/" crossorigin="anonymous"></script>
        <style>
            .container-fluid
            {
                background-color: whitesmoke;
                height: 100%;
                
            }
        </style>
    </head>
    <body>

    
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-4"></div>
                <div class="col-sm-4 bg-light" style="margin-top: 10%; border-radius: 10px;">
                <h4 class="text-center mt-3 mb-3">Forget Password</h4>
                <?php
                    $conn=mysqli_connect("localhost","root","","interntest");
                    if(!$conn)
                    {
                        echo"Connection Failed";
                    }

                    include('smtp/class.phpmailer.php');

                    if(isset($_POST['sub']))
                    {
                        $email=$_POST['email'];
                        $sel="SELECT * from register WHERE email='$email'";
                        $query=mysqli_query($conn,$sel) or die(mysqli_error($conn));
                        
                        $emailcount=mysqli_num_rows($query);
                        
                        if($emailcount)
                        {
                            $data=mysqli_fetch_assoc($query);
                            $uid=$data['email'];
                            $username=$data['name'];
                            $subject="Password Reset";
                            $body="Hii, $username. Click here too reset your password http://localhost/interntest/resetpass.php?email=$uid";
                            echo $body;
                            $sender_email="FROM: avinashk8650@gmail.com";

                            if(mail($email,$subject,$body,$sender_email))
                            {
                                ?>
                                    <script> alert('check your mail to reset your password');</script>
                                <?php
                                header("location:signin.php");
                            }
                            else
                            {
                                ?>
                                    <div class="alert">Email Sending Failed...</div>
                                <?php
                            }
                        }
                        else
                        {
                            ?>
                                <div class="alert alert-danger" role="alert">Email Not Valid...</div>
                            <?php
                        }
                    }
                ?>
                    <form action="" method="post">
                        <label class="mb-2">Enter your entered email</label>
                        <input type="email" class="mb-3 form-control" name="email" placeholder="Enter Your Entered Email..."/>
                        <input type="submit" value="Sent Mail" class="btn btn-primary btn-block" name="sub"/>
                    </form>
                </div>
                <div class="col-sm-4"></div>
            </div>
        </div>
    </body>
</html>