<?php
    define('SERVER_ROOT','http://localhost/interntest/');
?>