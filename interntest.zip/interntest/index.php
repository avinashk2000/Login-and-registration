
<?php
    session_start();
    if(isset($_SESSION['email']) && isset($_SESSION['password']))
    {
        ?>
            <html>
                <head>
                    <title>Interntest</title>
                    <meta charset="utf-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1">
                    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
                    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
                    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
                    <style>
                        #link
                        {
                            text-decoration: none;
                            color: white;
                            font-weight: bolder;
                            font-size: large;
                        }
                        #link:hover
                        {
                            color:gray !important;
                        }
                        .dropdown-menu
                        {
                            text-align: center !important;
                            border: none !important;
                            width: 18% !important;
                            margin-top: 1.5% !important;
                            background-color: transparent !important;
                        }
                    </style>
                </head>
                <body>
                    <div class="container-fluid">
                        <div class="row bg-info">
                            <div class="col-sm-9 mb-3 mt-3">
                                <h3 style="margin-left: 5%; color:white;">InternTest</h3>
                            </div>
                            <div class="col-sm-2 mb-3 mt-3">
                                <a id="link" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?= $_SESSION['email'];?></a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="logout.php">Sign Out</a>
                                </div>
                            </div>
                            <div class="col-sm-1"></div>
                        </div>
                    </div>
                </body>
            </html>
        <?php
    }
    else
    {
        ?>
            <html>
                <head>
                    <meta charset="utf-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1">
                    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
                    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-eMNCOe7tC1doHpGoWe/6oMVemdAVTMs2xqW4mwXrXsW0L84Iytr2wi5v2QjrP/xp" crossorigin="anonymous"></script>
                    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.min.js" integrity="sha384-cn7l7gDp0eyniUwwAZgrzD06kc/tftFf19TOAs2zVinnD/C7E91j9yyk5//jjpt/" crossorigin="anonymous"></script>
                    <style>
                        #link
                        {
                            font-weight: bolder;
                            font-size: large;
                        }
                        #link:hover
                        {
                            color:gray !important;
                        }
                    </style>
                </head>
                <body>
                    <div class="container-fluid">
                        <div class="row bg-info">
                            <div class="col-sm-10 mb-3 mt-3">
                                <h3 style="margin-left: 5%; color:white;">InternTest</h3>
                            </div>
                            <div class="col-sm-2 mb-3 mt-3">
                                <a href="signin.php" style="margin-left: auto; text-decoration:none; color:white;" id="link">Sign In/Sign Up</a>
                            </div>
                        </div>
                    </div>
                </body>
            </html>
        <?php
    }
?>