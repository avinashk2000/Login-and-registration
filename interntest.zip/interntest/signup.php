<html>
    <head>
        <title>Sign Up</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-eMNCOe7tC1doHpGoWe/6oMVemdAVTMs2xqW4mwXrXsW0L84Iytr2wi5v2QjrP/xp" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.min.js" integrity="sha384-cn7l7gDp0eyniUwwAZgrzD06kc/tftFf19TOAs2zVinnD/C7E91j9yyk5//jjpt/" crossorigin="anonymous"></script>
        <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="
        crossorigin="anonymous"></script>
        <style>
            .container-fluid
            {
                background-color: whitesmoke;
                height: 100%;
            }
            span
            {
                color: red;
            }
        </style>
    </head>
    <body>
        <?php
            session_start();
            $conn=mysqli_connect("localhost","root","","interntest");
            if(!$conn)
            {
                echo "Connection error";
            }
            if(isset($_POST['sub']))
            {
                $name=$_POST['name'];
                $email=$_POST['email'];
                $password=$_POST['password'];

                $_SESSION['email']=$email;
                $_SESSION['password']=$password;

                $ins="INSERT INTO register(name,email,password) values('$name','$email','$password')";
                $query=mysqli_query($conn,$ins) or die(mysqli_error($conn));
                if($query)
                {
                    header("location:index.php");
                }
                else
                {
                    echo "<script> alert('Not Registered'); </script>";
                }
            }
        ?>
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-4"></div>
                <div class="col-sm-4 bg-light" style="margin-top: 10%; border-radius: 10px;">
                    <h4 class="text-center mt-3">Sign in to start your session</h4>
                    <form action="" id="form" method="post" enctype="multipart/form-data">
                        <label class="mb-2">Full Name : <span id="ferror"></span></label>
                        <input type="text" name="name" id="fname" placeholder="Enter Your Full name..." onkeyup="nvalid()" class="form-control mb-3"/>
                        <label class="mb-2">Email : <span id="ueerror"></span></label>
                        <input type="text" name="email" id="uemail" placeholder="Enter Your Email..." onkeyup="evalid()" class="form-control mb-3"/>
                        <label class="mb-2">Password : <span id="perror"></span></label>
                        <input type="password" name="password" id="pass" placeholder="Password..." onkeyup="pvalid()" class="form-control mb-4"/>
                        <a href="Signin.php" class="mb-3" style="text-decoration: none;">Allready Registered?</a><br/>
                        <input type="submit" id="submit" value="Sign In" class="btn btn-primary mt-3 mb-3" name="sub"/>
                    </form>
                </div>
                <script>
                    function nvalid()
                    {
                        if(form.fname.value=="")
                        {
                            document.getElementById('ferror').innerHTML="Plz fill your email*";
                            document.getElementById('fname').focus();
                            return false;
                        }
                        var fname = /^[a-zA-Z]{2,10}$/;
                        if(!fname.test(form.fname.value))
                        {
                            document.getElementById('ferror').innerHTML="Plz use valid email";
                            return false;	
                        }
                        else
                        {
                            document.getElementById('ferror').innerHTML="";
                        }
                    }

                    function evalid()
                    {
                        if(form.uemail.value=="")
                        {
                            document.getElementById('ueerror').innerHTML="Plz fill your email*";
                            document.getElementById('email').focus();
                            return false;
                        }
                        var uemail = /^[a-zA-Z0-9\.\_]+@[a-zA-Z]{3,7}\.[a-zA-Z]{3,7}$/;
                        if(!uemail.test(form.uemail.value))
                        {
                            document.getElementById('ueerror').innerHTML="Plz use valid email";
                            return false;	
                        }
                        else
                        {
                            document.getElementById('ueerror').innerHTML="";
                        }
                    }
                    function pvalid()
                    {
                        if(form.pass.value=="")
                        {
                            document.getElementById('perror').innerHTML="Plz fill your password*";
                            document.getElementById('pass').focus();
                            return false;
                        }
                        else
                        {
                            document.getElementById('perror').innerHTML="";
                        }
                    }
                </script>
                <div class="col-sm-4"></div>
            </div>
        </div>
    </body>
</html>